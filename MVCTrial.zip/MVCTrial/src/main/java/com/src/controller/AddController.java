package com.src.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AddController {

	@RequestMapping(name="/add", method = RequestMethod.GET)
	public ModelAndView add(@RequestParam(name = "t1") int n1, @RequestParam(name = "t2") int n2) {
		int res = n1 + n2;
		ModelAndView mv = new ModelAndView();
		
		return new ModelAndView("display.jsp", "sum", res);
	}
}
